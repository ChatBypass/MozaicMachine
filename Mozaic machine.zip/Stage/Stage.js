/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 240,
        y: 180
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars.cats = 1200;
    this.vars.countedcats = 57600;
    this.vars.Highscore = 57600;

    this.watchers.countedcats = new Watcher({
      label: "CountedCats",
      style: "large",
      visible: true,
      value: () => this.vars.countedcats,
      x: 304,
      y: 180
    });
    this.watchers.Highscore = new Watcher({
      label: "☁ Highscore",
      style: "large",
      visible: true,
      value: () => this.vars.Highscore,
      x: 647,
      y: 180
    });
  }
}
