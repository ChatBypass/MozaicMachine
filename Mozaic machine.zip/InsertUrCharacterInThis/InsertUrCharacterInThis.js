/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class InsertUrCharacterInThis extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "normal costume",
        "./InsertUrCharacterInThis/costumes/normal costume.svg",
        { x: 48, y: 50 }
      ),
      new Costume(
        "ALWAYS KEEP THIS",
        "./InsertUrCharacterInThis/costumes/ALWAYS KEEP THIS.svg",
        { x: 1.0912777382756644, y: 0.14844719662687567 }
      )
    ];

    this.sounds = [
      new Sound("Meow", "./InsertUrCharacterInThis/sounds/Meow.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.KEY_PRESSED, { key: "r" }, this.whenKeyRPressed),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      ),
      new Trigger(Trigger.KEY_PRESSED, { key: "q" }, this.whenKeyQPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "e" }, this.whenKeyEPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "x" }, this.whenKeyXPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "z" }, this.whenKeyZPressed),
      new Trigger(Trigger.KEY_PRESSED, { key: "c" }, this.whenKeyCPressed),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.KEY_PRESSED, { key: "m" }, this.whenKeyMPressed)
    ];
  }

  *whenKeyRPressed() {
    this.stage.vars.cats += 10;
    this.effects.mosaic += 10;
  }

  *whenKeySpacePressed() {
    this.stage.vars.cats = 0;
    this.effects.clear();
    this.size = 100;
  }

  *whenKeyQPressed() {
    this.costume = "ALWAYS KEEP THIS";
    this.size += 5;
    this.costume = "normal costume";
  }

  *whenKeyEPressed() {
    this.size -= 5;
    this.costume = "normal costume";
  }

  *whenKeyXPressed() {
    this.size -= 50;
    this.costume = "normal costume";
  }

  *whenKeyZPressed() {
    this.costume = "ALWAYS KEEP THIS";
    this.size += 50;
    this.costume = "normal costume";
  }

  *whenKeyCPressed() {
    this.stage.vars.cats += 100;
    this.effects.mosaic += 100;
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.countedcats.visible = false;
    this.stage.vars.cats = 0;
    this.effects.clear();
    this.size = 100;
  }

  *countcats(mozaicEffect) {
    this.stage.watchers.countedcats.visible = true;
    this.stage.vars.countedcats = mozaicEffect;
    if (this.toNumber(this.stage.vars.cats) === 0) {
      this.stage.vars.countedcats = 1;
    }
    this.stage.vars.Highscore = this.stage.vars.countedcats;
  }

  *whenKeyMPressed() {
    yield* this.countcats(
      (this.toNumber(this.stage.vars.cats) / 5) *
        (this.toNumber(this.stage.vars.cats) / 5)
    );
  }
}
